
import { initNavbar } from './navbar.js';
import { initLoad } from './load.js';
// import { initializeNavbarAlerts } from './alert.js';
import { initScrollHighlight } from './scroll.js'; 

initNavbar();
initLoad();
initScrollHighlight();
// initializeNavbarAlerts();
console.log('Webpack Running! :)');
